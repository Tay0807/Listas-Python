lado = int(input("Digite a quangtidade de lados: "))
medida = int(input("Digite as medidas: "))

if lado == 3:
    perimetro = medida + medida + medida
    print(f"Triângulo - Perimetro:{perimetro} ")
elif lado == 4:
    perimetro = medida * medida
    print(f"Quadrado - Perimetro:{perimetro}")
elif lado == 5:
    print(f"Pentagono ")
else:
    print("Poligono não identificado")