numero = int(input("Informe um número: "))

if numero % 2 == 0:
    print("É par")
else:
    print("É impar")