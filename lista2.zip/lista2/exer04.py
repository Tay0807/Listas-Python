num = int(input("Digite um número:"))
numdois = int(input("Digite outro número:"))

if  (num % numdois == 0):
    print(f"{num} é divísivel por {numdois}")
else:
    print(f"{num} não é divisivel por {numdois}")