idade = int(input("Digite sua idade: "))
trabalho = int(input("Digite seu tempo de trabalho: "))

if idade >= 65 or trabalho >= 30 or idade >= 60 and trabalho >= 25:
    print("Você pode se aposentar")
else:
    print("Não pode se aposentar")
     