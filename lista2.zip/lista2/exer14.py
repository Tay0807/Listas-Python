ident = int(input("Digite seu número de identifiação: "))
nota_um = float(input("Digite sua primeira nota: "))
nota_dois = float(input("Digite sua segunda nota: "))
nota_tres = float(input("Digite sua terceira nota: "))
me = float(input("Digite a mpedia dos execícios: "))

calculo = (nota_um + (nota_dois*2) + (nota_tres*3) + me)/7

if calculo >= 9:
    conceito = "A"
elif calculo > 7.5 and calculo < 9:
    conceito = "B"
elif calculo > 6 and calculo <= 7.5:
    conceito = "C"
elif calculo > 4 and calculo <= 4:
    conceito = "d"
else:
    conceito = "E"

if conceito == "A" or conceito == "B" or conceito == "C":
    aprovacao = "Aprovado"
else:
    aprovacao = "Reprovado"

print(f"O aluno {ident} foi {aprovacao} com conceito {conceito} (MA = {calculo:.2f}) ")