dia = int(input("Digite o dia: "))
mes = int(input("Digite o mês: "))
ano = int(input("Digite o ano: "))

data = f"{dia}/{mes}/{ano} "

if mes >= 1 and mes <= 12:
    if (mes == 1 or mes == 3 or mes == 5 or mes == 7 or mes == 8 or mes == 10 or mes == 12) and dia <= 31:
        data += " é uma data válida!"
    else:
        if (mes == 4 or mes == 6 or mes == 9 or mes == 11) and dia <= 30:
            data += " é uma data válida!"
        else: 
            if ((ano % 400 == 0) or (ano % 4 == 0) and (ano % 100 != 0)) and mes == 2 and dia <= 29:
                data += " é uma data válida!"
            else:
                if mes == 2 and dia <= 28:
                    data += " é uma data válida!"
                else:
                    data += " não é uma data válida!" 
else: 
    data += " não é uma data válida!"
        
print(data)
        