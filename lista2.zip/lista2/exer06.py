num = float(input("Informe o primeiro valor: "))
num2 = float(input("Informe o segundo valor: "))

if num > num2:
    print(f"O {num} é maior")
#elif é o else if
elif num < num2:
    print(f"O {num2} é maior")
else:
    print("São iguais")