num = float(input("Informe o primeiro valor: "))
num2 = float(input("Informe o segundo valor: "))

if num == num2:
    print("São iguais!")
else:
    print("São diferentes!")
