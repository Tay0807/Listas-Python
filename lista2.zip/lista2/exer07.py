alt = float(input("Informe sua altura:"))
sexo = input("Informe seu sexo:F para femenino e M para masculino \n")

if sexo == "F" or sexo == "f":
    calculof = (62.1 * alt) - 45.7
    print(f"peso ideal: {calculof}Kg")
else:
    calculom =  (72.7 * alt) - 58
    print(f"peso ideal: {calculom:.2f}Kg")