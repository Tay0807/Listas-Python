n = int(input("Digite um número: "))

if n > 10:
    print(f"{n} é maior que 10")
else:
    print(f"{n} é menor que 10")