codigo = int(input("Digite seu código: "))
nota_um = float(input("Digite a primeira nota: "))
nota_dois = float(input("Digite a segunda nota: "))
nota_tres = float(input("Digite a terceira nota: "))

if nota_um > nota_dois and nota_um > nota_tres:
    nota_maior = nota_um
    nota_menor = nota_dois
    nota_menorD = nota_tres
elif nota_dois > nota_um and nota_dois > nota_tres:
    nota_maior = nota_dois
    nota_menor = nota_um
    nota_menorD = nota_tres
else:
    nota_maior = nota_tres
    nota_menor = nota_dois
    nota_menorD = nota_um
    
calculo = ((nota_maior*4) + (nota_menor*3) + (nota_menorD*3))/10

if calculo >= 5:
    aprovacao = "Aprovado"
else:
    aprovacao = "Reprovado"

print(f"código = {codigo}  nota1 = {nota_um}  nota2 = {nota_dois}  nota3 = {nota_tres}  média = {calculo}  {aprovacao} ")