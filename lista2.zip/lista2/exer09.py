salario = float(input("Digite seu salário bruto: "))
proventos = float(input("Digite os proventos: "))

if salario <= 5000:
    soma = (salario + proventos) 
    desconto = salario * 0.05
    salario_liquido = soma - desconto
    print(f"salário liquido: {salario_liquido}")
else:
    soma = (salario + proventos) 
    desconto = salario * 0.1
    salario_liquido = soma - desconto
    print(f"salário liquido: {salario_liquido}")