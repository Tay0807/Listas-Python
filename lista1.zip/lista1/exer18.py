fitas = int(input("Digite a quantidade de fitas: "))
valor = float(input("Digite o valor por aluguel: "))

alugadas = fitas/3
fanual = (alugadas*valor)*12
multas = ((alugadas / 10) * valor) * 0.1
estragam = fitas*0.02
total = ((fitas - estragam) + (fitas/10))

print(f"Faturamento anual: {fanual} \n Valor multas mensal: {multas} \n Total de fitas ao final de 1 ano: {total}")


