dmaior = float(input("Digite a diagonal maior: "))
dmenor = float(input("Digite a diagonal menor: "))
area = (dmaior*dmenor)/2

print(f"Área: {area}")