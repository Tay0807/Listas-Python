quo= int(input("Digite o quociente: "))
um = int(input("Digite o primeiro termo: "))

decimo = um * quo ** (10 -1)

print(f"Décimo termo: {decimo}")