n = input("Digite um número: ") 

print("Centena:", n[0])
print("Dezena:", n[1])
print("Unidade:", n[2])
