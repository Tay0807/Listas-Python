lar = float(input("Digite a largura: "))
alt = float(input("Digite a altura: "))
perimetro = (lar*2)+(alt*2)
area = lar*alt

print(f"Perimetro: {perimetro}\n Área: {area}")

