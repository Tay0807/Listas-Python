n = (input("Digite um caracter: "))
nd = (input("Digite outro caracter: "))

print(f"O usuário digitou {n} e {nd}!")
