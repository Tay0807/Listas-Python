s = float(input("Digite seu salário minímo: "))
e = float(input("Digite a quantidade de energia: "))

quilow = (s/7)*(e/100)
umq = quilow / e
desconto = quilow / 10
total = quilow - desconto

print(f"Valor do quilowats: ${umq:.2f}\n Valor a ser pago: ${quilow:.2f}\n Valor com desconto: ${total:.2f} ")

