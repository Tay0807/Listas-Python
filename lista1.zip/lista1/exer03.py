n = int(input("Digite um número: "))
ant = n - 1
suc = n + 1
print(f"{ant} e {suc}")