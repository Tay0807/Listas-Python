a = int(input("Digite o a:"))
b = int(input("Digite o b:"))

print(f"Após leitura: A={a} B={b}")

a , b = b , a

print(f"Após a troca: A={a} B={b}")