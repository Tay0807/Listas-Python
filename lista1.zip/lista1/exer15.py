raio = float(input("Digite o raio: "))
alt = float(input("Digite a altura: "))
pi = 3.1416
result = pi*(raio*raio)*alt

print(f"volume da lata: {result:.1f}")