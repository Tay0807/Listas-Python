n = input("Digite um número: ") 

print( n[2], n[1], n[0])
