valor = float(input("Digite o valor:"))
taxa = float(input("Digite a taxa:"))
tempo = int(input("Digite o tempo:"))

result = valor + (valor * (taxa/100) * tempo)
print(f"Valor da prestação: S${result:.2f}")