base = float(input("Digite a base: "))
alt = float(input("Digite a altura: "))
area = (base*alt)/2

print(f"Área: {area}")