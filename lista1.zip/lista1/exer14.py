valor = int(input("Digite o valor atual: "))
result = valor*0.9
novo = valor - result

print(f"valor com desconto de 9 por cento {novo}")