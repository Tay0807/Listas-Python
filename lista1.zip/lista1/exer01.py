n = float(input("Digite um número: "))
result = n*n
print(f"O quadrado do número é {result}")