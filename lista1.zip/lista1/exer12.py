razao = int(input("Digite a razão: "))
um = int(input("Digite o primeiro termo: "))

decimo = um + (10 - 1)* razao

print(f"Décimo termo: {decimo}")