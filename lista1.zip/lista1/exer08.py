r = float(input("Digite o raio: "))
pi = 3.14
circu = (2 * pi)*(r)
area = (r * r)*pi

print(f"Circunferência: {circu:.2f} \n Área: {area}")

