conta = input("Digite a conta: ")

numinverso = int(conta[2] + conta[1] + conta[0])
um = int(conta) + numinverso
dois = str(um)

p = dois[0]
s = dois[1]
t = dois[2]

soma = (p*1)+(s*2)+(t*3)

result = str(soma)
verificador = result[len(result) - 1]


print(f"{verificador}")